# Téléchargements et usages - Essais CLiniques Accessibles Interconnectés pour la Recherche ouverts à l'Ecosystème v0.3.1

* [**Table of Contents**](toc.md)
* [**Autres Ressources**](autres_ressources.md)
* **Téléchargements et usages**

## Téléchargements et usages

### Téléchargements et usage

L'implementation guide contient un package [téléchargeable ici](package.tgz) permettant de valider les instances par rapport aux profils qu'il contient.

Pour cela, il suffit de télécharger le [package.tgz](package.tgz) et l'importer dans un serveur, par exemple sur hapi en suivant ce [script python](https://github.com/nmdp-bioinformatics/igloader) open source.

Vous pourrez ensuite utiliser l'opération [$validate](https://www.hl7.org/fhir/resource-operation-validate.html) pour valider les instances de ressource contre un profil issu de cette spécification.

Ensemble des ressources téléchargeables :

* [L'ensemble de la specification (zip)](full-ig.zip)
* [Package (tgz)](package.tgz)
* [JSON Définitions (zip)](definitions.json.zip)
* [JSON Exemples (zip)](examples.json.zip)
* [XML Definitions (zip)](definitions.xml.zip)
* [XML Exemples (zip)](examples.ttl.zip)
* [Turtle Définitions](definitions.ttl.zip)

